package RoomReservation;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="Management_table")
public class Management {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @PostRemove
    public void onPostRemove(){
        RoomRejected roomRejected = new RoomRejected();
        BeanUtils.copyProperties(this, roomRejected);
        roomRejected.publishAfterCommit();


    }

    @PrePersist
    public void onPrePersist(){
        RoomConfirmed roomConfirmed = new RoomConfirmed();
        BeanUtils.copyProperties(this, roomConfirmed);
        roomConfirmed.publishAfterCommit();

        //Following code causes dependency to external APIs
        // it is NOT A GOOD PRACTICE. instead, Event-Policy mapping is recommended.

        RoomReservation.external.Payment payment = new RoomReservation.external.Payment();
        // mappings goes here
        Application.applicationContext.getBean(RoomReservation.external.PaymentService.class)
            .payRequest(payment);


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }




}
